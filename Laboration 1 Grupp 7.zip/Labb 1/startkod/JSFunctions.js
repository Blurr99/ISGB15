"use strict";

/**
 * Globalt objekt som innehåller de attribut som ni skall använda.
 * Initieras genom anrop till funktionern initGlobalObject().
 */
let oGameData = {};

/**
 * Initerar det globala objektet med de attribut som ni skall använda er av.
 * Funktionen tar inte emot några värden.
 * Funktionen returnerar inte något värde.
 */
oGameData.initGlobalObject = function() {

    //Datastruktur för vilka platser som är lediga respektive har brickor
    //oGameData.gameField = Array('', '', '', '', '', '', '', '', '');
    
    /* Testdata för att testa rättningslösning */
    //oGameData.gameField = Array('X', 'X', 'X', '', '', '', '', '', '');
    //oGameData.gameField = Array('X', '', '', 'X', '', '', 'X', '', '');
    //oGameData.gameField = Array('X', '', '', '', 'X', '', '', '', 'X');
    //oGameData.gameField = Array('', '', 'X', '', 'X', '', 'X', '', '');
    //oGameData.gameField = Array('X', 'O', 'X', 'O', 'X', 'O', 'O', 'X', 'O');

    //Indikerar tecknet som skall användas för spelare ett.
    oGameData.playerOne = "X";

    //Indikerar tecknet som skall användas för spelare två.
    oGameData.playerTwo = "O";

    //Kan anta värdet X eller O och indikerar vilken spelare som för tillfället skall lägga sin "bricka".
    oGameData.currentPlayer = "";

    //Nickname för spelare ett som tilldelas från ett formulärelement,
    oGameData.nickNamePlayerOne = "";

    //Nickname för spelare två som tilldelas från ett formulärelement.
    oGameData.nickNamePlayerTwo = "";

    //Färg för spelare ett som tilldelas från ett formulärelement.
    oGameData.colorPlayerOne = "";

    //Färg för spelare två som tilldelas från ett formulärelement.
    oGameData.colorPlayerTwo = "";

    //"Flagga" som indikerar om användaren klickat för checkboken.
    oGameData.timerEnabled = false;

    //Timerid om användaren har klickat för checkboxen. 
    oGameData.timerId = null;

}
//Kollar om någon spelare har vunnit horisontellt
function checkHorizontal() {
    console.log(oGameData.gameField);
    if((oGameData.gameField[0] === "X") && (oGameData.gameField[1] === "X") && (oGameData.gameField[2] === "X") 
    || (oGameData.gameField[3] === "X") && (oGameData.gameField[4] === "X") && (oGameData.gameField[5] === "X") 
    || (oGameData.gameField[6] === "X") && (oGameData.gameField[7] === "X") && (oGameData.gameField[8] === "X") ){
        return 1;
    }

    else if((oGameData.gameField[0] === "O") && (oGameData.gameField[1] === "O") && (oGameData.gameField[2] === "O")
    || (oGameData.gameField[3] === "O") && (oGameData.gameField[4] === "O") && (oGameData.gameField[5] === "O")
    || (oGameData.gameField[6] === "O") && (oGameData.gameField[7] === "O") && (oGameData.gameField[8] === "O") ) {
        return 2;
    }
 
}
//Kollar om någon spelare har vunnit vertikalt
function checkVertical() {
    if((oGameData.gameField[0] === "X") && (oGameData.gameField[3] === "X") && (oGameData.gameField[6] === "X") 
    || (oGameData.gameField[1] === "X") && (oGameData.gameField[4] === "X") && (oGameData.gameField[7] === "X") 
    || (oGameData.gameField[2] === "X") && (oGameData.gameField[5] === "X") && (oGameData.gameField[8] === "X") ){
        return 1;
    }

    else if((oGameData.gameField[0] === "O") && (oGameData.gameField[3] === "O") && (oGameData.gameField[6] === "O")
    || (oGameData.gameField[1] === "O") && (oGameData.gameField[4] === "O") && (oGameData.gameField[7] === "O")
    || (oGameData.gameField[2] === "O") && (oGameData.gameField[5] === "O") && (oGameData.gameField[8] === "O") ) {
        return 2;
    }
}
//Kollar om någon spelare har vunnit diagonalt
function checkDiagonal() {
    if((oGameData.gameField[6] === "X") && (oGameData.gameField[4] === "X") && (oGameData.gameField[2] === "X") 
    || (oGameData.gameField[0] === "X") && (oGameData.gameField[4] === "X") && (oGameData.gameField[8] === "X") ){
        return 1;
    }

    else if((oGameData.gameField[2] === "O") && (oGameData.gameField[4] === "O") && (oGameData.gameField[6] === "O")
    || (oGameData.gameField[8] === "O") && (oGameData.gameField[4] === "O") && (oGameData.gameField[0] === "O") ) {
        return 2;
    }
}

//kollar om det finns tomma fält kvar annars so är det oavgjort
function oavgjort() {
    let svar = 3; 

    for (let i=0; i< oGameData.gameField.length; i++){
        if (oGameData.gameField[i] == ''){
            svar = 0;
        }   
    }
    return svar;
}

/*
 * Kontrollerar för tre i rad.
 * Returnerar 0 om det inte är någon vinnare, 
 * returnerar 1 om spelaren med ett kryss (X) är vinnare,
 * returnerar 2 om spelaren med en cirkel (O) är vinnare eller
 * returnerar 3 om det är oavgjort.
 * Funktionen tar inte emot några värden.
 */
        

// Funktion som returnerar olika värden, beroende på hur spelet slutar
oGameData.checkForGameOver = function() {
        // kallar på check-funktioner och returnerar värde beroende på resulatat
        var horz = checkHorizontal();
        var vert = checkVertical();
        var dia = checkDiagonal();
        
        if((horz === 1 ) || (vert === 1) || (dia === 1)) {
            console.log("Spelare ett har vunnit");
            return 1;
        }
        else if((horz === 2) || (vert === 2) || (dia === 2)) {
            console.log("Spelare två har vunnit");
            return 2;
        }
       
        else { // Kontrollerar spelets slut ifall det inte finns någon vinnare
            var oav = oavgjort();
            if (oav === 0){
                console.log("Det finns ingen vinnare");
                return 0;
            }
            else{
                console.log("Spelet är oavgjort");
                return 3;
            }
            
        }
    }
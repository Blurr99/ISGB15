"use strict";

/**
 * Globalt objekt som innehåller de attribut som ni skall använda.
 * Initieras genom anrop till funktionern initGlobalObject().
 */
let oGameData = {};

/**
 * Initerar det globala objektet med de attribut som ni skall använda er av.
 * Funktionen tar inte emot några värden.
 * Funktionen returnerar inte något värde.
 */
oGameData.initGlobalObject = function() {

    //Datastruktur för vilka platser som är lediga respektive har brickor
    //oGameData.gameField = Array('', '', '', '', '', '', '', '', '');
    
    /* Testdata för att testa rättningslösning */
    //oGameData.gameField = Array('X', 'X', 'X', '', '', '', '', '', '');
    //oGameData.gameField = Array('X', '', '', 'X', '', '', 'X', '', '');
    //oGameData.gameField = Array('X', '', '', '', 'X', '', '', '', 'X');
    //oGameData.gameField = Array('', '', 'X', '', 'X', '', 'X', '', '');
    //oGameData.gameField = Array('X', 'O', 'X', 'O', 'X', 'O', 'O', 'X', 'O');

    //Indikerar tecknet som skall användas för spelare ett.
    oGameData.playerOne = "X";

    //Indikerar tecknet som skall användas för spelare två.
    oGameData.playerTwo = "O";

    //Kan anta värdet X eller O och indikerar vilken spelare som för tillfället skall lägga sin "bricka".
    oGameData.currentPlayer = "";

    //Nickname för spelare ett som tilldelas från ett formulärelement,
    oGameData.nickNamePlayerOne = "";

    //Nickname för spelare två som tilldelas från ett formulärelement.
    oGameData.nickNamePlayerTwo = "";

    //Färg för spelare ett som tilldelas från ett formulärelement.
    oGameData.colorPlayerOne = "";

    //Färg för spelare två som tilldelas från ett formulärelement.
    oGameData.colorPlayerTwo = "";

    //"Flagga" som indikerar om användaren klickat för checkboken.
    oGameData.timerEnabled = false;

    //Timerid om användaren har klickat för checkboxen. 
    oGameData.timerId = null;

}

function checkHorizontal (){
    console.log(oGameData.gameField);
    if((oGameData.gameField[0] === "X") && (oGameData.gameField[1] === "X") && (oGameData.gameField[2] === "X") 
    || (oGameData.gameField[3] === "X") && (oGameData.gameField[4] === "X") && (oGameData.gameField[5] === "X") 
    || (oGameData.gameField[6] === "X") && (oGameData.gameField[7] === "X") && (oGameData.gameField[8] === "X") ){
        return 1;
    }

    else if((oGameData.gameField[0] === "O") && (oGameData.gameField[1] === "O") && (oGameData.gameField[2] === "O")
    || (oGameData.gameField[3] === "O") && (oGameData.gameField[4] === "O") && (oGameData.gameField[5] === "O")
    || (oGameData.gameField[6] === "O") && (oGameData.gameField[7] === "O") && (oGameData.gameField[8] === "O") ) {
        return 2;
    }

   
}

function checkVertical() {
    if((oGameData.gameField[0] === "X") && (oGameData.gameField[3] === "X") && (oGameData.gameField[6] === "X") 
    || (oGameData.gameField[1] === "X") && (oGameData.gameField[4] === "X") && (oGameData.gameField[7] === "X") 
    || (oGameData.gameField[2] === "X") && (oGameData.gameField[5] === "X") && (oGameData.gameField[8] === "X") ){
        return 1;
    }

    else if((oGameData.gameField[0] === "O") && (oGameData.gameField[3] === "O") && (oGameData.gameField[6] === "O")
    || (oGameData.gameField[1] === "O") && (oGameData.gameField[4] === "O") && (oGameData.gameField[7] === "O")
    || (oGameData.gameField[2] === "O") && (oGameData.gameField[5] === "O") && (oGameData.gameField[8] === "O") ) {
        return 2;
    }

    else{
        return 3;
    }
}

function checkDiagonal() {
    if((oGameData.gameField[6] === "X") && (oGameData.gameField[4] === "X") && (oGameData.gameField[2] === "X") 
    || (oGameData.gameField[0] === "X") && (oGameData.gameField[4] === "X") && (oGameData.gameField[8] === "X") ){
        return 1;
    }

    else if((oGameData.gameField[2] === "O") && (oGameData.gameField[4] === "O") && (oGameData.gameField[6] === "O")
    || (oGameData.gameField[8] === "O") && (oGameData.gameField[4] === "O") && (oGameData.gameField[0] === "O") ) {
        return 2;
    }
    else{
        return 3;
    }
}

function oavgjort(){
    for (let i=0; i< oGameData.gameField.length; i++){
        if (oGameData.gameField[i] !== "");
        return 3;
    }
}

/**
 * Kontrollerar för tre i rad.
 * Returnerar 0 om det inte är någon vinnare, 
 * returnerar 1 om spelaren med ett kryss (X) är vinnare,
 * returnerar 2 om spelaren med en cirkel (O) är vinnare eller
 * returnerar 3 om det är oavgjort.
 * Funktionen tar inte emot några värden.
 */
oGameData.checkForGameOver = function() {
        console.log("i checkforgameover");
        
        var horz = checkHorizontal();
        if(horz === 1) {
            console.log("Spelare ett har vunnit");
            return 1;
        }
        else if(horz === 2) {
            console.log("Spelare två har vunnit");
            return 2;
        }
       
        var vert = checkVertical();
        if(vert === 1) {
            console.log("Spelare ett har vunnit");
            return 1;
        }

        else if(vert === 2) {
            console.log("Spelare två har vunnit");
            return 2;
        }
        
        var dia = checkDiagonal();
        if(dia === 1) {
            console.log("Spelare ett har vunnit");
            return 1;
        }
        else if(dia === 2) {
            console.log("Spelare två har vunnit");
            return 2;
        }

       
        else {
            var oav = oavgjort();
            if (oav === 3){
                console.log("Spelet är oavgjort");
                return 3;
            }
            else{
                return 0;
            }
            
        }
    }

    /*
    function checkVertikal(){
        
    }

    function checkDiagonalLeftToRight() {
        
    }

    function checkDiagonalRightToLeft() {
        
    }
   */



//oGameData.checkForGameOver();

